# simple-python-redis-auth

Biblioteca python para lidar com autenticação e autorização de usuários utilizando redis.

## Authors

- [Gabriel Xará](https://github.com/gxara)

## Utilizando o AuthManager

### Instalando o pacote

```bash
pip install rest_api_auth_manager
```

### Adicionar um usuário

#TODO

### Associar uma role a um usuário

#TODO

### Autenticação e autorização de requisição

#TODO

### Executando os testes:

`pytest`
